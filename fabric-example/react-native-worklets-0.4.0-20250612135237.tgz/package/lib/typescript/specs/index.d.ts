export declare const WorkletsTurboModule: import("./NativeWorkletsModule").Spec | null;
//# sourceMappingURL=index.d.ts.map